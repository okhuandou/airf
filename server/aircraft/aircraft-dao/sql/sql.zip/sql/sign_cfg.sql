truncate table sign_cfg;
insert into sign_cfg set id=1,item_id=1,descr='星星',item_num=100,item_id2=0,item_num2=0;
insert into sign_cfg set id=2,item_id=1,descr='星星',item_num=200,item_id2=0,item_num2=0;
insert into sign_cfg set id=3,item_id=1,descr='星星',item_num=300,item_id2=1000,item_num2=1;
insert into sign_cfg set id=4,item_id=1,descr='星星',item_num=400,item_id2=0,item_num2=0;
insert into sign_cfg set id=5,item_id=1,descr='星星',item_num=600,item_id2=0,item_num2=0;
insert into sign_cfg set id=6,item_id=1,descr='星星',item_num=800,item_id2=0,item_num2=0;
insert into sign_cfg set id=7,item_id=1,descr='星星',item_num=1000,item_id2=2000,item_num2=1;
