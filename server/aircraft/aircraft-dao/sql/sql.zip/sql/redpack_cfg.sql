truncate table redpack_cfg;
insert into redpack_cfg set id=1,type=1,min=0.01,max=0.20;
insert into redpack_cfg set id=2,type=2,min=0.50,max=1.15;
insert into redpack_cfg set id=3,type=3,min=1.00,max=2.00;
